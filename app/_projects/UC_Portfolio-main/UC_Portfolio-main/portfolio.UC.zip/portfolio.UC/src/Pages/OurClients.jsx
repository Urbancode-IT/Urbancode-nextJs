import React from "react";
import "./OurClients.css";

const allClients = [
  { name: "Google", logo: "https://www.vectorlogo.zone/logos/google/google-ar21.svg" },
  { name: "Microsoft", logo: "https://www.vectorlogo.zone/logos/microsoft/microsoft-ar21.svg" },
  { name: "Amazon", logo: "https://www.vectorlogo.zone/logos/amazon/amazon-ar21.svg" },
  { name: "Meta", logo: "https://www.vectorlogo.zone/logos/meta/meta-ar21.svg" },
  { name: "Zoho", logo: "https://www.vectorlogo.zone/logos/zoho/zoho-ar21.svg" },
  { name: "HCL", logo: "https://www.vectorlogo.zone/logos/hcltech/hcltech-ar21.svg" },
  { name: "Infosys", logo: "https://upload.wikimedia.org/wikipedia/commons/thumb/9/95/Infosys_logo.svg/512px-Infosys_logo.svg.png" },
  { name: "Wipro", logo: "https://www.vectorlogo.zone/logos/wipro/wipro-ar21.svg" },
  { name: "IBM", logo: "https://www.vectorlogo.zone/logos/ibm/ibm-ar21.svg" },
  { name: "PayPal", logo: "https://www.vectorlogo.zone/logos/paypal/paypal-ar21.svg" },
  { name: "Cisco", logo: "https://www.vectorlogo.zone/logos/cisco/cisco-ar21.svg" },
  { name: "Oracle", logo: "https://www.vectorlogo.zone/logos/oracle/oracle-ar21.svg" },
  { name: "Capgemini", logo: "https://upload.wikimedia.org/wikipedia/commons/thumb/1/1d/Capgemini_logo.svg/512px-Capgemini_logo.svg.png" },
  { name: "Deloitte", logo: "https://upload.wikimedia.org/wikipedia/commons/thumb/2/2b/Deloitte.svg/512px-Deloitte.svg.png" },
  { name: "Accenture", logo: "https://www.vectorlogo.zone/logos/accenture/accenture-ar21.svg" },
  { name: "TCS", logo: "https://upload.wikimedia.org/wikipedia/commons/thumb/b/b1/Tata_Consultancy_Services_Logo.svg/512px-Tata_Consultancy_Services_Logo.svg.png" },
];

const OurClients = () => {
  return (
    <section className="our-clients" id="our-clients">
      <div className="our-clients-container">
        {/* Header */}
        <div className="our-clients-header">
          <h2>Our Students Thrive in <span className="text-green">Top MNCs</span></h2>
          <p className="our-clients-desc">
            Empowering students with industry-relevant skills to build successful and lasting professional careers.
          </p>
        </div>

        {/* Scrolling logos (Single Marquee) */}
        <div className="clients-marquee">
          <div className="clients-marquee-track marquee-left">
            {[...allClients, ...allClients, ...allClients].map((client, i) => (
              <div className="clients-logo-item" key={i}>
                <img
                  src={client.logo}
                  alt={client.name}
                  className="clients-logo-img"
                  loading="lazy"
                  onError={(e) => {
                    // Fallback to text if image fails
                    e.target.style.display = 'none';
                    const parent = e.target.parentNode;
                    if (!parent.querySelector('.logo-fallback')) {
                      const span = document.createElement('span');
                      span.className = 'logo-fallback';
                      span.innerText = client.name;
                      span.style.fontWeight = 'bold';
                      span.style.color = 'var(--text-muted)';
                      parent.appendChild(span);
                    }
                  }}
                />
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default OurClients;
