import React, { useState } from "react";
import { MapPin, Navigation, Building2, ReceiptText } from "lucide-react";
import "./ContactSection.css";

const BRANCHES = {
  velachery: {
    name: "Velachery Branch",
    address: "Velachery, Chennai, Tamil Nadu",
    mapUrl: "https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3888.346582143411!2d80.21111111111111!3d12.95!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3a525d8d8d8d8d8d%3A0x8d8d8d8d8d8d8d8d!2sUrbancode%20Edutech!5e0!3m2!1sen!2sin!4v1711888888888!5m2!1sen!2sin"
  },
  pallikaranai: {
    name: "Pallikaranai Branch",
    address: "Pallikaranai, Chennai, Tamil Nadu",
    mapUrl: "https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3888.75!2d80.2166666!3d12.9333333!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3a525d0000000000%3A0x0000000000000000!2sUrbancode%20Edutech%20Pallikaranai!5e0!3m2!1sen!2sin!4v1711999999999!5m2!1sen!2sin"
  }
};

const ContactSection = () => {
  const [activeBranch, setActiveBranch] = useState("velachery");

  return (
    <section className="contact" id="contact">
      {/* Background Orbs */}
      <div className="contact__orb orb-1"></div>
      <div className="contact__orb orb-2"></div>
      
      <div className="contact__container">
        {/* Left: Chat/Email/Phone | Right: Enquiry Form */}
        <div className="contact__split">
          <div className="contact__split-left">
            {/* Info Grid - Three Cards */}
            <div className="contact__info-row">
              <div className="info-card info-card--green float-1">
                <div className="info-card__icon-wrap-3d">
                  <img 
                    src="https://upload.wikimedia.org/wikipedia/commons/6/6b/WhatsApp.svg" 
                    alt="WhatsApp" 
                    width="32" 
                    height="32" 
                    className="info-card__icon-svg" 
                  />
                </div>
                <div className="info-card__text">
                  <span className="info-card__label white-text">LET'S TALK!</span>
                  <h3 className="info-card__value white-text">WhatsApp Chat</h3>
                </div>
              </div>

              <div className="info-card info-card--white float-2">
                <div className="info-card__icon-wrap-3d">
                  <span role="img" aria-label="email" className="info-card__icon-3d">✉️</span>
                </div>
                <div className="info-card__text">
                  <span className="info-card__label green-text">EMAIL</span>
                  <h3 className="info-card__value green-text">admin@urbancode.in</h3>
                </div>
              </div>

              <div className="info-card info-card--white float-3">
                <div className="info-card__icon-wrap-3d">
                  <span role="img" aria-label="phone" className="info-card__icon-3d">📞</span>
                </div>
                <div className="info-card__text">
                  <span className="info-card__label green-text">PHONE</span>
                  <h3 className="info-card__value dark-text">+91 98787 98797</h3>
                </div>
              </div>

              <div className="info-card info-card--white float-2 info-card--details">
                <div className="info-card__icon-wrap-3d">
                  <Building2 size={20} className="info-card__icon-lucide" aria-hidden="true" />
                </div>
                <div className="info-card__text">
                  <span className="info-card__label green-text">COMPANY</span>
                  <h3 className="info-card__value dark-text info-card__value--wrap">
                    Urbancode Edutech Solutions Pvt Ltd
                  </h3>
                  <div className="info-card__divider" />
                  <div className="info-card__row">
                    <ReceiptText size={18} className="info-card__icon-lucide subtle" aria-hidden="true" />
                    <div>
                      <span className="info-card__label green-text">GST NO</span>
                      <div className="info-card__gst dark-text">33AADCU726Q1ZR</div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div className="contact__divider"></div>

          <div className="contact__split-right">
            {/* Enquiry Form */}
            <div className="contact__form-box">
              <form className="contact__form">
                <div className="form__row">
                  <div className="form__group">
                    <label>Name</label>
                    <input type="text" placeholder="Name" />
                  </div>
                  <div className="form__group">
                    <label>Mail ID</label>
                    <input type="email" placeholder="Mail ID" />
                  </div>
                </div>
                <div className="form__row">
                  <div className="form__group">
                    <label>Mobile No</label>
                    <input type="tel" placeholder="Mobile No" />
                  </div>
                  <div className="form__group">
                  <label>Interested In</label>
                  <select required defaultValue="">
                    <option value="" disabled>Interested In</option>
                    <option value="mern">MERN Full Stack Course</option>
                    <option value="python">Python Full Stack</option>
                    <option value="corp">Corporate Training</option>
                    <option value="soft">Software Development</option>
                  </select>
                </div>
                </div>
                <div className="form__group">
                  <label>Message</label>
                  <textarea placeholder="Message"></textarea>
                </div>
                <button type="submit" className="form__submit">
                  Send Message →
                </button>
              </form>
            </div>
          </div>
        </div>

        {/* Location Section with Dual Branch Support (moved below like before) */}
        <div className="location-section">
          <div className="branch-selector">
            <button 
              className={`branch-btn ${activeBranch === "velachery" ? "active" : ""}`}
              onClick={() => setActiveBranch("velachery")}
            >
              <MapPin size={18} /> Velachery Branch
            </button>
            <button 
              className={`branch-btn ${activeBranch === "pallikaranai" ? "active" : ""}`}
              onClick={() => setActiveBranch("pallikaranai")}
            >
              <MapPin size={18} /> Pallikaranai Branch
            </button>
          </div>

          <div className="location-card">
            <div className="location-icon-container">
              <div className="location-pin-wrap">
                <MapPin color="#FF0000" size={40} className="location-pin-icon" />
              </div>
            </div>
            <div className="location-details">
              <span className="location-tag">LOCATIONS</span>
              <h3 className="location-title">{BRANCHES[activeBranch].name}</h3>
              <p className="location-info">{BRANCHES[activeBranch].address} • Mon–Sat, 9AM–7PM IST</p>
            </div>
          </div>
        </div>

        {/* Map / branch details */}
        <div className="form-section-header">
          <div className="form-badge">
            SAY HELLO <span className="waving-hand">👋</span>
          </div>
          <h2 className="form-heading">Let's get you <span className="text-green">more info</span></h2>
          <p className="form-subheading">Visit our {BRANCHES[activeBranch].name}</p>
          
          <div className="interactive-map-container">
            <div className="map-wrapper">
              <div className="map-live">
                <iframe 
                  src={BRANCHES[activeBranch].mapUrl} 
                  width="100%" 
                  height="100%" 
                  style={{ border: 0 }} 
                  allowFullScreen="" 
                  loading="lazy" 
                  referrerPolicy="no-referrer-when-downgrade"
                  title={BRANCHES[activeBranch].name}
                  key={activeBranch}
                ></iframe>
              </div>
            </div>
          </div>

          <div className="form-dots">
            <span></span><span className="active"></span><span></span>
          </div>
        </div>

        {/* External Links Buttons */}
        <div className="contact__external-links">
          <a href="https://www.urbancode.in/" target="_blank" rel="noopener noreferrer" className="external-link__btn website">
            Visit Our Website →
          </a>
          <a href="https://wa.me/919878798797" target="_blank" rel="noopener noreferrer" className="external-link__btn whatsapp">
            <span role="img" aria-label="whatsapp-bubble" className="whatsapp-icon">💬</span> WhatsApp Us
          </a>
        </div>
      </div>
    </section>
  );
};

export default ContactSection;